package ru.biderman.studenttest.domain;

public interface Answer {
}
