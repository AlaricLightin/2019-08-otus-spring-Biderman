package ru.biderman.studenttest.service;

import ru.biderman.studenttest.domain.Answer;
import ru.biderman.studenttest.domain.Question;

public interface AnswerService {

}
