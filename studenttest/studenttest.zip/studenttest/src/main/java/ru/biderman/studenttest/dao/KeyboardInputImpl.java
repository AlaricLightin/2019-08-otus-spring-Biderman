package ru.biderman.studenttest.dao;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.Function;

public class KeyboardInputImpl implements KeyboardInput {
    private final Scanner scanner = new Scanner(System.in);

    public KeyboardInputImpl(PrintStream printStream) {
    }

    public void setInputStream(InputStream inputStream) {

    }

    @Override
    public <T> Optional<T> readValue(String prompt, Function<String, KeyboardValue<T>> createKeyboardValueFunc) {
        System.out.println(prompt);
        System.out.println("(Для прекращения тестирования введите q.)");
        while (true) {
            String s = scanner.nextLine();
            if("q".equals(s))
                return Optional.empty();

            KeyboardValue<T> value = createKeyboardValueFunc.apply(s);
            if (value.getCheckError().isPresent())
                System.out.println(value.getCheckError());
            else
                return value.getResult();
        }
    }
}
